# Mishra Group of Industries — Attendance App Starter

This is a Flutter UI starter for Android + iOS using the supplied Mishra Group logo.

Configured business scale:
- 972,700 employees
- 1,810 branches

Included UI:
- Employee login
- Employee dashboard
- GPS verification placeholder
- Selfie verification placeholder
- Check-in / check-out flow
- Monthly attendance sheet
- Leave request
- Admin dashboard
- Branch / geofence management placeholder
- Attendance/report/payroll placeholders

Important:
This package is a frontend starter/prototype, not a production attendance backend.
For production at this scale, connect it to a secure backend with:
- authentication and role-based access
- PostgreSQL/Cloud SQL or equivalent
- object storage for selfies
- geofencing/location verification
- audit logs
- queue/event processing for high-volume attendance
- encryption, retention policies, and access controls
- PDF/Excel report generation
- push notifications
- payroll integration

Demo login:
MGI001 / demo123

Run:
1. Install Flutter.
2. Run `flutter pub get`.
3. Run `flutter run` for a connected Android/iOS target.


## Mobile-only APK build

After uploading this project to GitHub:
1. Open the repository.
2. Tap **Actions**.
3. Select **Build Android APK**.
4. Tap **Run workflow**.
5. Wait for the workflow to finish.
6. Open the completed workflow run and download the artifact named `mishra-group-attendance-apk`.
7. Extract the downloaded artifact and install the APK on your Android phone.

The workflow builds a release APK in GitHub's cloud; no PC or local Flutter installation is required.
