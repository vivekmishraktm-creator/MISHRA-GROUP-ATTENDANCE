import 'package:flutter/material.dart';

void main() => runApp(const MishraAttendanceApp());

const navy = Color(0xFF071D42);
const gold = Color(0xFFE7B94F);

class MishraAttendanceApp extends StatelessWidget {
  const MishraAttendanceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mishra Group Attendance',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: navy),
        scaffoldBackgroundColor: const Color(0xFFF4F7FB),
        useMaterial3: true,
      ),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    final id = TextEditingController(text: 'MGI001');
    final pass = TextEditingController(text: 'demo123');

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 430),
              child: Card(
                elevation: 2,
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Image.asset('assets/mishra_logo.jpg', width: 110, height: 110),
                      const SizedBox(height: 16),
                      const Text('MISHRA GROUP OF INDUSTRIES',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: navy)),
                      const Text('Attendance Management',
                          style: TextStyle(color: Color(0xFF65748B))),
                      const SizedBox(height: 24),
                      TextField(controller: id, decoration: const InputDecoration(
                        labelText: 'Employee ID / Mobile', border: OutlineInputBorder())),
                      const SizedBox(height: 12),
                      TextField(controller: pass, obscureText: true, decoration: const InputDecoration(
                        labelText: 'Password', border: OutlineInputBorder())),
                      const SizedBox(height: 18),
                      SizedBox(width: double.infinity, child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy),
                        onPressed: () => Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (_) => const DashboardPage())),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 13),
                          child: Text('LOGIN', style: TextStyle(fontWeight: FontWeight.w800)),
                        ),
                      )),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int tab = 0;
  bool gps = false, selfie = false, checkedIn = false, checkedOut = false;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        gps: gps, selfie: selfie, checkedIn: checkedIn, checkedOut: checkedOut,
        onGps: () => setState(() => gps = true),
        onSelfie: () => setState(() => selfie = true),
        onIn: () => setState(() => checkedIn = true),
        onOut: () => setState(() => checkedOut = true),
      ),
      const AttendancePage(),
      const LeavePage(),
      const AdminPage(),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: navy,
        foregroundColor: Colors.white,
        title: const Text('Mishra Group of Industries', style: TextStyle(fontSize: 16)),
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), label: 'Attendance'),
          NavigationDestination(icon: Icon(Icons.mail_outline), label: 'Leave'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'Admin'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final bool gps, selfie, checkedIn, checkedOut;
  final VoidCallback onGps, onSelfie, onIn, onOut;
  const HomePage({super.key, required this.gps, required this.selfie, required this.checkedIn,
    required this.checkedOut, required this.onGps, required this.onSelfie, required this.onIn, required this.onOut});

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Hello, Employee', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          const Text('MGI001 • October 2026', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 18),
          Row(children: [
            Expanded(child: _stat('Check-in', checkedIn ? '09:05' : '—')),
            Expanded(child: _stat('Check-out', checkedOut ? '18:02' : '—')),
          ]),
        ],
      ))),
      const SizedBox(height: 10),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Mark Attendance', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          Text('GPS: ${gps ? "Verified ✓" : "Not verified"}'),
          Text('Selfie: ${selfie ? "Captured ✓" : "Not captured"}'),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: onGps, icon: const Icon(Icons.location_on_outlined), label: const Text('Verify GPS'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: onSelfie, icon: const Icon(Icons.camera_alt_outlined), label: const Text('Selfie'))),
          ]),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: navy),
            onPressed: (!gps || !selfie || checkedIn) ? null : onIn,
            child: const Text('MARK PRESENT / CHECK-IN'))),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: navy),
            onPressed: (!checkedIn || checkedOut) ? null : onOut,
            child: const Text('CHECK-OUT'))),
        ],
      ))),
    ]);
  }

  Widget _stat(String title, String value) => Padding(
    padding: const EdgeInsets.only(right: 8),
    child: Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF4F7FB), borderRadius: BorderRadius.circular(12)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: navy)),
        Text(title, style: const TextStyle(fontSize: 12, color: Colors.grey)),
      ]),
    ),
  );
}

class AttendancePage extends StatelessWidget {
  const AttendancePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Monthly Attendance Sheet', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    Card(child: DataTable(columns: const [
      DataColumn(label: Text('Date')), DataColumn(label: Text('In')), DataColumn(label: Text('Out')), DataColumn(label: Text('Status'))
    ], rows: const [
      DataRow(cells: [DataCell(Text('01 Oct')), DataCell(Text('09:05')), DataCell(Text('18:02')), DataCell(Text('Present'))]),
      DataRow(cells: [DataCell(Text('02 Oct')), DataCell(Text('09:12')), DataCell(Text('—')), DataCell(Text('Present'))]),
    ])),
    const SizedBox(height: 8),
    FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.download), label: const Text('Export PDF / Excel')),
  ]);
}

class LeavePage extends StatelessWidget {
  const LeavePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Leave Request', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      DropdownButtonFormField(value: 'Casual Leave', items: const [
        DropdownMenuItem(value: 'Casual Leave', child: Text('Casual Leave')),
        DropdownMenuItem(value: 'Sick Leave', child: Text('Sick Leave')),
        DropdownMenuItem(value: 'Privilege Leave', child: Text('Privilege Leave')),
      ], onChanged: (_) {}, decoration: const InputDecoration(labelText: 'Leave type', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      const TextField(decoration: InputDecoration(labelText: 'Reason', border: OutlineInputBorder())),
      const SizedBox(height: 12),
      FilledButton(onPressed: () {}, child: const Text('SUBMIT REQUEST')),
    ]))),
  ]);
}

class AdminPage extends StatelessWidget {
  const AdminPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Admin Dashboard', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    Row(children: [
      Expanded(child: _metric('Employees', '9,72,700')),
      const SizedBox(width: 8), Expanded(child: _metric('Branches', '1,810')),
    ]),
    const SizedBox(height: 12),
    Card(child: ListTile(leading: const Icon(Icons.people_outline, color: navy),
      title: const Text('Employee Management'), subtitle: const Text('Add, edit and assign employees / branches'),
      trailing: const Icon(Icons.chevron_right))),
    Card(child: ListTile(leading: const Icon(Icons.assessment_outlined, color: navy),
      title: const Text('Reports & Payroll'), subtitle: const Text('Attendance, overtime, salary and leave reports'),
      trailing: const Icon(Icons.chevron_right))),
    Card(child: ListTile(leading: const Icon(Icons.location_on_outlined, color: navy),
      title: const Text('Branch / Geofence Settings'), subtitle: const Text('Configure attendance zones for branches'),
      trailing: const Icon(Icons.chevron_right))),
  ]);

  static Widget _metric(String label, String value) => Card(
    child: Padding(padding: const EdgeInsets.all(14), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: navy)),
        Text(label, style: const TextStyle(color: Colors.grey))],
    )),
  );
}
